window.__SUPABASE_CONFIG__ = Object.freeze({"url":"https://fcuqorihzypcstmcgvru.supabase.co","key":"sb_publishable_sQClCX3zvC1Ja2d2Oia7qA_JtRMGZuS"});
